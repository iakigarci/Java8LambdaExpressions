package examenR;

public class Par{

    private int columna;
    private double valor;


    public Par(int pColumna, double pValor){
        columna = pColumna;
        valor = pValor;
    }

    public int getColumna() {
        return columna;
    }


    public double getValor() {
        return valor;
    }
    
}